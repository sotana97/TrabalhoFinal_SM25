

#include <tm4c123gh6pm.h>
#include <stdbool.h>                        // Library of Standard Boolean Types
#include <variaveis_globais.h>
#include <definicoes.h>
void EnableInterrupts(void);

//PWM para controlar o PF1 que � o RGB vermelho

void PortF_Init(void){
    SYSCTL_RCGCGPIO_R |= 0x20; //activate port F
    while ((SYSCTL_PRGPIO_R & 0x20) == 0) {}; // wait for port F ready
    GPIO_PORTF_AFSEL_R |= 0x02; //habilita fun��o alternativa do PF1
    GPIO_PORTF_AFSEL_R |= 0x04; //habilita fun��o alternativa do PF2
    GPIO_PORTF_AFSEL_R |= 0x08; //habilita fun��o alternativa do PF3
    GPIO_PORTF_PCTL_R &= ~0x000000F0; //Limpando os bits do pino PF1
    GPIO_PORTF_PCTL_R &= ~0x00000F00; //Limpando os bits do pino PF2
    GPIO_PORTF_PCTL_R &= ~0x0000F000; //Limpando os bits do pino PF3
    GPIO_PORTF_PCTL_R |= 0x0050; //configure PF1 as M1PWM5 [0101 0000]
    GPIO_PORTF_PCTL_R |= 0x0500; //configure PF2 as M1PWM6 [0101  0000 0000]
    GPIO_PORTF_PCTL_R |= 0x5000; //configure PF3 as M1PWM7 [0101 0000 0000 0000]
    GPIO_PORTF_AMSEL_R &= ~0x2;  //disable analog functionality on PF1
    GPIO_PORTF_AMSEL_R &= ~0x04; //disable analog functionality on PF2
    GPIO_PORTF_AMSEL_R &= ~0x08; //disable analog functionality on PF3
    GPIO_PORTF_DEN_R |= 0x02;    //enable digital I/O on PF1 [0010]
    GPIO_PORTF_DEN_R |= 0x04;    //enable digital I/O on PF2 [0100]
    GPIO_PORTF_DEN_R |= 0x08;    //enable digital I/O on PF3 [1000]
}


void PortC_Init(void){ //Azul
    SYSCTL_RCGCGPIO_R |= 0x4; //activate port C
    while ((SYSCTL_PRGPIO_R & 0x4) == 0) {}; // wait for port C ready
    GPIO_PORTC_AFSEL_R |= 0x10; //habilita fun��o alternativa do PC4
    GPIO_PORTC_PCTL_R &= ~0x000F0000; //Limpando os bits do pino PC4
    GPIO_PORTC_PCTL_R |= 0x40000; //configure PC4 as M0PWM6 [0100 0000 0000 0000 0000]
    GPIO_PORTC_AMSEL_R &= ~0x10; //disable analog functionality on PC4
    GPIO_PORTC_DEN_R |= 0x10;     //enable digital I/O on PC4 [0001 0000]
}



void PWM_Init(uint16_t period, uint16_t duty) {
    SYSCTL_RCGCPWM_R |= 0x02;             // 1) activate PWM modulo 1
    SYSCTL_RCGCPWM_R |= 0x01;             // 1) activate PWM modulo 1
    SYSCTL_RCC_R = 0x00100000 |           // 7) use PWM divider
                   (SYSCTL_RCC_R & (~0x000E0000)); // configure for /2 divider

 //M1PWM5 -> PF1 (red) an launchpad  e no boosterPack
 //M1PWM6 -> PF2 (blue) an launchpad
 //M1PWM7 -> PF3 (green) an launchpad
 //M1PWM7 -> PC4 (blue) no boosterPack
//Obs: N�meros pares de PWM -> GEN A, n�mero impares GEN B
    // Generator 2 - M1PWM5 (PF1)
    PWM1_2_CTL_R = 0;                     // 3) Desativa generator 2
    PWM1_2_GENB_R = 0xC08;                 // 4) Sa�da baixa em LOAD, alta em CMPA na descida
    PWM1_2_LOAD_R = period - 1;           // 5) Per�odo do PWM
    PWM1_2_CMPB_R = duty - 1;             // 6) Duty cycle
    PWM1_2_CTL_R |= 0x01;                 // 7) Ativa generator 2

    // Generator 2 - M0PWM6 (PC4)
    PWM0_3_CTL_R = 0;                     // 3) Desativa generator 3
    PWM0_3_GENA_R = 0xC8;                 // 4) Sa�da baixa em LOAD, alta em CMPA na descida
    PWM0_3_LOAD_R = period - 1;           // 5) Per�odo do PWM
    PWM0_3_CMPA_R = duty - 1;             // 6) Duty cycle
    PWM0_3_CTL_R |= 0x01;                 // 7) Ativa generator 3

    // Generator 3 - M1PWM6 (PF2)     // Generator 3 - M1PWM7 (PF3)

    PWM1_3_CTL_R = 0;                     // 8) Desativa generator 3
    PWM1_3_LOAD_R = period- 1;           // 10) Per�odo igual ao de M1PWM5
    PWM1_3_CMPA_R = duty*5 - 1;             // 11) Duty cycle
    PWM1_3_CMPB_R = duty - 1;             //  Duty cycle para segunda sa�da
    PWM1_3_GENA_R = 0xC8;;                 // 9) Sa�da baixa em LOAD, alta em CMPA na descida
    PWM1_3_GENB_R =  0xC08;                // a sa�da sobe no comparador (CMPA) e desce no LOAD.
    PWM1_3_CTL_R |= 0x01;                 // Ativa generator 3

    PWM1_ENABLE_R |= (1 << 5); // Ativa M1PWM5 (PF1)
    PWM1_ENABLE_R |= (1 << 6); // Ativa M1PWM6 (PF2)
    PWM1_ENABLE_R |= (1 << 7); // Ativa M1PWM7 (PF3)
    PWM0_ENABLE_R |= (1 << 6); // Ativa M0PWM6 (PC4)
}


// ------------BSP_Joystick_Init------------
// Inicializa um pino GPIO para entrada, correspondente
// ao pino J1.5 (bot�o Select) do BoosterPack.
// Inicializa dois pinos ADC, correspondentes aos
// pinos J1.2 (X) e J3.26 (Y) do BoosterPack.
void BSP_Joystick_Init(uint32_t period){
  volatile uint32_t delay;

  SYSCTL_RCGCGPIO_R |= 0x0000001A; // 1) ativa o clock para as Portas E, D e B
  while((SYSCTL_PRGPIO_R&0x1A) != 0x1A){}; // aguarda estabiliza��o dos clocks
                                   // 2) n�o � necess�rio desbloquear PE4, PD3 ou PB5
  GPIO_PORTE_AMSEL_R &= ~0x10;     // 3a) desativa anal�gico no PE4
  GPIO_PORTD_AMSEL_R |= 0x08;      // 3b) ativa anal�gico no PD3
  GPIO_PORTB_AMSEL_R |= 0x20;      // 3c) ativa anal�gico no PB5
                                   // 4) configura PE4 como GPIO
  GPIO_PORTE_PCTL_R = (GPIO_PORTE_PCTL_R&0xFFF0FFFF)+0x00000000;
  GPIO_PORTE_DIR_R &= ~0x10;       // 5a) define PE4 como entrada
  GPIO_PORTD_DIR_R &= ~0x08;       // 5b) define PD3 como entrada
  GPIO_PORTB_DIR_R &= ~0x20;       // 5c) define PB5 como entrada
  GPIO_PORTE_AFSEL_R &= ~0x10;     // 6a) desativa fun��o alternativa no PE4
  GPIO_PORTD_AFSEL_R |= 0x08;      // 6b) ativa fun��o alternativa no PD3
  GPIO_PORTB_AFSEL_R |= 0x20;      // 6c) ativa fun��o alternativa no PB5
  GPIO_PORTE_DEN_R |= 0x10;        // 7a) ativa I/O digital no PE4
  GPIO_PORTD_DEN_R &= ~0x08;       // 7b) ativa funcionalidade anal�gica no PD3
  GPIO_PORTB_DEN_R &= ~0x20;       // 7c) ativa funcionalidade anal�gica no PB5

  SYSCTL_RCGCADC_R |= 0x00000001;  // 1) ativa o ADC0
  while((SYSCTL_PRADC_R&0x01) == 0){}; // 2) aguarda estabiliza��o do clock
                                   // 3-7) Inicializa��o do GPIO em fun��es mais espec�ficas
  ADC0_PC_R &= ~0xF;               // 8) limpa o campo de taxa m�xima de amostragem
  ADC0_PC_R |= 0x1;                //    configura para 125K amostras/segundo
  ADC0_SSPRI_R = 0x3210;           // 9) Sequenciador 3 tem a menor prioridade

  SYSCTL_RCGCTIMER_R |= 0x01;    // Ativa clock do Timer0
  delay = SYSCTL_RCGCTIMER_R;    // For�a sincroniza��o

  TIMER0_CTL_R = 0x00000000; // disable timer0A during setup
  TIMER0_CTL_R |= 0x00000020; // enable timer0A trigger to ADC
  TIMER0_CFG_R = 0; // configure for 32-bit timer mode
  TIMER0_TAMR_R = 0x00000002; // configure for periodic mode
  TIMER0_TAPR_R = 0; // prescale value for trigger
  TIMER0_TAILR_R = period-1; // start value for trigger
  TIMER0_IMR_R = 0x00000000; // disable all interrupts
  TIMER0_CTL_R |= 0x00000001; // enable timer0A 32-b, periodic

  ADC0_ACTSS_R &= ~0x02;                  // Desativa SS1
  ADC0_EMUX_R = (ADC0_EMUX_R & ~0xF0) | 0x50; // SS1 com trigger por Timer (0x5 << 4)

  ADC0_SSMUX1_R = 0x004B;                 // canais 11 (PB5) e 3 (PD3)
  ADC0_SSCTL1_R = 0x0060;

  ADC0_IM_R |= 0x0002;                    // Habilita interrup��o para SS1
  ADC0_ACTSS_R |= 0x02;                   // Reativa SS1

  NVIC_PRI3_R = (NVIC_PRI3_R & 0x00FFFFFF) | 0x60000000;
  NVIC_EN0_R |= (1 << 15); // Habilita interrup��o

  EnableInterrupts();
}


