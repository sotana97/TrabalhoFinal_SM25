

#ifndef CLOCK_INIT_H_
#define CLOCK_INIT_H_


void Clock_Init(long SYSDIV_var);



#endif /* CLOCK_INIT_H_ */
