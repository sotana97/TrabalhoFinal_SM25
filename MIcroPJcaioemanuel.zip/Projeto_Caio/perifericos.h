/*
 * perifericos.h
 *
 *  Created on: 28 de jun de 2025
 *      Author: CaioEmanuel
 */

#ifndef PERIFERICOS_H_
#define PERIFERICOS_H_



void PortF_Init(void);
void PortC_Init(void);
void PWM_Init(uint16_t period, uint16_t duty);
void static adcinit(void);
void BSP_Joystick_Init(uint32_t period);
void BSP_Joystick_Input(uint16_t *x, uint16_t *y, uint8_t *select);
#endif /* PERIFERICOS_H_ */
