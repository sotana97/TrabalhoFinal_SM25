

#ifndef DEFINICOES_H_
#define DEFINICOES_H_


#define SELECT    (*((volatile uint32_t *)0x40024040))  /* PE4 */



#endif /* DEFINICOES_H_ */
