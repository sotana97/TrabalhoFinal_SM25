
#include <tm4c123gh6pm.h>
#include <stdbool.h>                        // Library of Standard Boolean Types
#include <variaveis_globais.h>
#include <definicoes.h>

void alterar_azul(uint16_t period, float duty){
    PWM0_3_CMPA_R=(uint16_t)(period*duty*0.99)-1;
}

void alterar_verde(uint16_t period, float duty){
    PWM1_2_CMPB_R=(uint16_t)(period*duty*0.99)-1;
}

void alterar_vermelho(uint16_t period, float duty){
    PWM1_3_CMPB_R=(uint16_t)(period*duty*0.99)-1;
}

void alterar_buzzer(uint16_t period, float duty){
    PWM1_3_CMPA_R=(uint16_t)(period*duty*0.98)-1;
}
