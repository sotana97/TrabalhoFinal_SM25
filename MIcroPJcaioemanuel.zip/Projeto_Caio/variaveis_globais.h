
#include <stdint.h>                         // Library of Standard Integer Types
#include <stdbool.h>                        // Library of Standard Boolean Types

#ifndef VARIAVEIS_GLOBAIS_H_
#define VARIAVEIS_GLOBAIS_H_

//PWM general

extern uint16_t pwm_period;

//PWM vermelho
extern float red_duty;
extern float red_duty0;

//PWM azul
extern float blue_duty;
extern float blue_duty0;

//PWM verde
extern float green_duty;
extern float green_duty0;

//PWM buzzer
extern float buzzer_duty;
extern float buzzer_duty0;

extern uint16_t joystick_x;
extern uint16_t joystick_y;
extern uint16_t joystick_select;


//extern float MSTel;
//extern float MITel_Ref;
//extern float MITel_Ref0;

#endif /* VARIAVEIS_GLOBAIS_H_ */
