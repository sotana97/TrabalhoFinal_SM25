
#ifndef FUNCOES_GERAIS_H_
#define FUNCOES_GERAIS_H_

#include <stdint.h>
#include <tm4c123gh6pm.h>

void alterar_azul(uint16_t period, float duty);

void alterar_verde(uint16_t period, float duty);

void alterar_vermelho(uint16_t period, float duty);

void alterar_buzzer(uint16_t period, float duty);

#endif /* FUNCOES_GERAIS_H_ */
