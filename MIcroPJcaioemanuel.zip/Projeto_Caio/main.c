

#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <tm4c123gh6pm.h>
#include <perifericos.h>
#include <clock_Init.h>
#include <funcoes_gerais.h>
#include <definicoes.h>


/**
 * main.c
 */

uint16_t pwm_period=40000;
float blue_duty=0;
float blue_duty0=0;
float red_duty0=0;
float red_duty=0;
float green_duty=0;
float green_duty0=0;
float buzzer_duty=0;
float buzzer_duty0=0;
uint16_t joystick_x=0;
uint16_t joystick_y=0;
uint16_t joystick_select=0;

void EnableInterrupts(void);

int main(void)
{
    Clock_Init(4);
    PortF_Init();
    PortC_Init();
    PWM_Init(pwm_period,0);

    BSP_Joystick_Init(160000);


    while(1){


        if(joystick_select==0){
            alterar_buzzer(pwm_period, 0.5);
        }else{
            alterar_buzzer(pwm_period, 0);
        }

        if (abs(joystick_x - 512) < 50 && abs(joystick_y - 512) < 50) {
            // Posi��o neutra -> Branco fraco
            alterar_verde(pwm_period, 0.9);
            alterar_vermelho(pwm_period, 0.9);
            alterar_azul(pwm_period, 0.9);
        }
        else if (joystick_x > joystick_y && joystick_y < 200) {
            // Para baixo -> Azul
            alterar_verde(pwm_period, 0);
            alterar_vermelho(pwm_period, 0);
            alterar_azul(pwm_period, 0.9);
        }
        else if (joystick_y > joystick_x && joystick_y > 800) {
            // Para cima -> Verde
            alterar_verde(pwm_period, 0.9);
            alterar_vermelho(pwm_period, 0);
            alterar_azul(pwm_period, 0);
        }
        else if (joystick_x > joystick_y &&  joystick_x > 500) {
            // Para a direita -> Amarelo
            alterar_verde(pwm_period, 0.9);
            alterar_vermelho(pwm_period, 0.9);
            alterar_azul(pwm_period, 0);
        }
        else if (joystick_x < joystick_y && joystick_x < 200) {
              // Para a esquerda -> Vermelho
                alterar_verde(pwm_period, 0);
                alterar_vermelho(pwm_period, 0.9);
                alterar_azul(pwm_period, 0.9);
        }
        else {
            // Fora de zona v�lida -> Apagar LEDs
            alterar_verde(pwm_period, 0);
            alterar_vermelho(pwm_period, 0);
            alterar_azul(pwm_period, 0);
        }

    }
}

void ADC0Seq1_Handler(void) {

    ADC0_ISC_R = 0x02; // limpa flag

    uint32_t amostra0 = ADC0_SSFIFO1_R & 0xFFF;
    uint32_t amostra1 = ADC0_SSFIFO1_R & 0xFFF;

    joystick_x = amostra0 >> 2;
    joystick_y = amostra1 >> 2;
    joystick_select = SELECT;
}
